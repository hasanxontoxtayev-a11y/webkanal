(() => {
  // src/background.ts
  var API_BASE_URL = "https://www.tubepilotpro.com";
  chrome.runtime.onInstalled.addListener(() => {
    console.log("[TubePilot AI] Universal YouTube HUD Extension Installed Successfully");
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "PING") {
      sendResponse({ status: "PONG", timestamp: Date.now() });
      return true;
    }
    if (message.type === "FETCH_STATUS") {
      fetch(`${API_BASE_URL}/api/extension/status`, { cache: "no-store" }).then((res) => res.json()).then((data) => sendResponse({ success: true, data })).catch((err) => sendResponse({ success: false, error: err?.message || "Network error" }));
      return true;
    }
    if (message.type === "FETCH_CONNECTED_CHANNEL") {
      fetch(`${API_BASE_URL}/api/channels/current`, { cache: "no-store" }).then((res) => res.json()).then((data) => sendResponse({ success: true, data })).catch((err) => sendResponse({ success: false, error: err?.message || "Network error" }));
      return true;
    }
    if (message.type === "FETCH_AUDIT") {
      const query = encodeURIComponent(message.query || "");
      fetch(`${API_BASE_URL}/api/channels/audit?q=${query}`, { cache: "no-store" }).then((res) => res.json()).then((data) => sendResponse({ success: true, data })).catch((err) => sendResponse({ success: false, error: err?.message || "Network error" }));
      return true;
    }
    return true;
  });
})();
//# sourceMappingURL=background.js.map
