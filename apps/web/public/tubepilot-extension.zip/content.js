(() => {
  // src/content.ts
  (function() {
    console.log("\u{1F680} [TubePilot AI] Content script active on:", window.location.href);
    const API_BASE_URL = "https://www.tubepilotpro.com";
    const HUD_CONTAINER_ID = "tubepilot-hud-root";
    const CHANNEL_CARD_ID = "tubepilot-vidiq-channel-card";
    const TOP_MASTHEAD_ID = "tp-masthead-bar";
    const VIEW_STATS_BTN_ID = "tp-view-stats-btn-id";
    const FLOATING_BADGE_ID = "tp-floating-quick-badge";
    let isCollapsed = false;
    let channelData = {
      channelTitle: "VELORA",
      channelHandle: "@velora-p5n",
      subscribers: "607",
      totalViews: "207,132",
      videoCount: "333",
      overallScore: 89,
      grade: "B+",
      vph: { currentVph: "150 VPH", peakVph: "510 VPH" },
      monetization: {
        estimatedRpm: "$0.85",
        regionBadge: "\u{1F1FA}\u{1F1FF} Uzbekistan",
        projectedMonthlyMin: "$43",
        projectedMonthlyMax: "$305"
      }
    };
    function sendMessagePromise(msg) {
      return new Promise((resolve) => {
        try {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage(msg, (response) => {
              if (chrome.runtime.lastError) {
                resolve(null);
              } else {
                resolve(response);
              }
            });
          } else {
            resolve(null);
          }
        } catch {
          resolve(null);
        }
      });
    }
    function injectAlwaysVisibleBadge() {
      if (document.getElementById(FLOATING_BADGE_ID)) return;
      const targetParent = document.body || document.documentElement;
      if (!targetParent) return;
      const badge = document.createElement("div");
      badge.id = FLOATING_BADGE_ID;
      badge.style.cssText = `
      position: fixed !important;
      bottom: 24px !important;
      right: 24px !important;
      z-index: 2147483647 !important;
      background: linear-gradient(135deg, #f59e0b, #d97706) !important;
      color: #000000 !important;
      font-weight: 900 !important;
      font-size: 13px !important;
      padding: 10px 18px !important;
      border-radius: 50px !important;
      box-shadow: 0 10px 25px rgba(0,0,0,0.6), 0 0 15px rgba(245,158,11,0.5) !important;
      cursor: pointer !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      user-select: none !important;
      transition: transform 0.2s, box-shadow 0.2s !important;
    `;
      const activeName = channelData.channelTitle || "YouTube";
      badge.innerHTML = `
      <span style="font-size:16px;">\u{1F680}</span>
      <span>TubePilot AI Active</span>
      <span style="font-size:10px; background:#000; color:#fbbf24; padding:2px 6px; border-radius:10px; font-weight:800;">${activeName}</span>
    `;
      badge.onmouseenter = () => {
        badge.style.transform = "scale(1.06)";
      };
      badge.onmouseleave = () => {
        badge.style.transform = "scale(1)";
      };
      badge.onclick = () => {
        const card = document.getElementById(CHANNEL_CARD_ID);
        if (card) {
          card.scrollIntoView({ behavior: "smooth", block: "center" });
        } else {
          window.open(`${API_BASE_URL}/uz/dashboard`, "_blank");
        }
      };
      targetParent.appendChild(badge);
    }
    function injectTopMasthead() {
      if (document.getElementById(TOP_MASTHEAD_ID)) return;
      const endContainer = document.querySelector("ytd-masthead #end #buttons") || document.querySelector("ytd-masthead #end") || document.querySelector("#masthead #end");
      if (!endContainer) return;
      const bar = document.createElement("div");
      bar.id = TOP_MASTHEAD_ID;
      bar.style.cssText = `
      display: inline-flex !important;
      align-items: center !important;
      margin-right: 12px !important;
      vertical-align: middle !important;
      z-index: 1000 !important;
    `;
      const title = channelData.channelTitle || "VELORA";
      const subs = channelData.subscribers || "607";
      const vph = channelData.vph?.currentVph || "150 VPH";
      const score = channelData.overallScore || 89;
      bar.innerHTML = `
      <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:20px;background:#0f172a;border:1px solid rgba(245,158,11,0.6);box-shadow:0 4px 15px rgba(0,0,0,0.5);font-size:12px;font-weight:700;color:#f1f5f9;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,sans-serif;">
        <span style="color:#fbbf24;font-weight:900;">\u{1F680} TubePilot:</span>
        <span>\u{1F465} ${subs}</span>
        <span style="color:#64748b;">\xB7</span>
        <span style="color:#34d399;">\u26A1 ${vph}</span>
        <span style="color:#64748b;">\xB7</span>
        <span style="color:#fb7185;">\u{1F3AF} ${score}/100</span>
        <span style="padding:2px 8px;border-radius:10px;background:rgba(16,185,129,0.25);color:#34d399;font-size:10px;font-weight:800;">\u{1F7E2} Ulangan</span>
      </div>
    `;
      bar.onclick = () => {
        const card = document.getElementById(CHANNEL_CARD_ID);
        if (card) {
          card.scrollIntoView({ behavior: "smooth", block: "center" });
        } else {
          window.open(`${API_BASE_URL}/uz/dashboard`, "_blank");
        }
      };
      endContainer.insertBefore(bar, endContainer.firstChild);
    }
    function injectChannelStatsCard() {
      if (document.getElementById(CHANNEL_CARD_ID)) return;
      const channelHeader = document.querySelector("ytd-tabbed-page-header") || document.querySelector('ytd-browse[page-subtype="channels"] #header') || document.querySelector("#channel-container") || document.querySelector("ytd-c4-tabbed-header-renderer") || document.querySelector("#page-header") || document.querySelector("#channel-header") || document.querySelector("#channel-tag")?.closest("div") || document.querySelector('ytd-browse[page-subtype="channels"] #primary');
      if (!channelHeader) return;
      const card = document.createElement("div");
      card.id = CHANNEL_CARD_ID;
      card.style.cssText = `
      margin: 16px 24px 20px 24px !important;
      padding: 18px 24px !important;
      background: #0f172a !important;
      border: 1px solid rgba(245, 158, 11, 0.4) !important;
      border-radius: 16px !important;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5) !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      color: #f1f5f9 !important;
      z-index: 10 !important;
      display: block !important;
    `;
      const title = channelData.channelTitle || "VELORA";
      const handle = channelData.channelHandle || "@velora-p5n";
      const subs = channelData.subscribers || "607";
      const views = channelData.totalViews || "207,132";
      const vph = channelData.vph?.currentVph || "150 VPH";
      const peakVph = channelData.vph?.peakVph || "510 VPH";
      const score = channelData.overallScore || 89;
      const estRpm = channelData.monetization?.estimatedRpm || "$0.85";
      const monthlyRange = channelData.monetization?.projectedMonthlyMin ? `${channelData.monetization.projectedMonthlyMin} \u2013 ${channelData.monetization.projectedMonthlyMax}` : "$43 \u2013 $305";
      const dashboardUrl = `${API_BASE_URL}/uz/dashboard`;
      card.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,0.08);">
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-size:16px;font-weight:900;color:#fbbf24;">\u{1F680} TubePilot Quick channel stats</span>
          <span style="font-size:11px;font-weight:800;padding:3px 10px;border-radius:12px;background:rgba(16,185,129,0.2);color:#34d399;border:1px solid rgba(16,185,129,0.3);">
            \u{1F7E2} Ulangan Workspace: ${title} (${handle})
          </span>
        </div>
        <a href="${dashboardUrl}" target="_blank" style="font-size:12px;font-weight:800;color:#38bdf8;text-decoration:none;">
          Boshqaruv paneli (Dashboard) \u2197
        </a>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));gap:12px;">
        <div style="padding:12px 16px;background:rgba(30,41,59,0.8);border-radius:12px;border:1px solid rgba(255,255,255,0.05);">
          <span style="display:block;font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;">Views gained (7 days)</span>
          <div style="font-size:17px;font-weight:900;color:#fff;">+12.4% <span style="font-size:11px;color:#34d399;">(${views} jami)</span></div>
        </div>
        <div style="padding:12px 16px;background:rgba(30,41,59,0.8);border-radius:12px;border:1px solid rgba(255,255,255,0.05);">
          <span style="display:block;font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;">Podpischiki</span>
          <div style="font-size:17px;font-weight:900;color:#fff;">${subs} obunachi <span style="font-size:10px;background:rgba(245,158,11,0.2);color:#fbbf24;padding:2px 6px;border-radius:6px;">Ranked #1</span></div>
        </div>
        <div style="padding:12px 16px;background:rgba(30,41,59,0.8);border-radius:12px;border:1px solid rgba(255,255,255,0.05);">
          <span style="display:block;font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;">Est. monthly earnings</span>
          <div style="font-size:17px;font-weight:900;color:#fff;">${monthlyRange} <span style="font-size:10px;background:rgba(56,189,248,0.2);color:#38bdf8;padding:2px 6px;border-radius:6px;">\u{1F1FA}\u{1F1FF} UZ CPM (${estRpm})</span></div>
        </div>
        <div style="padding:12px 16px;background:rgba(30,41,59,0.8);border-radius:12px;border:1px solid rgba(255,255,255,0.05);">
          <span style="display:block;font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;">Views velocity (VPH)</span>
          <div style="font-size:17px;font-weight:900;color:#fff;">${vph} <span style="font-size:11px;color:#34d399;">(Yuqori: ${peakVph})</span></div>
        </div>
        <div style="padding:12px 16px;background:rgba(30,41,59,0.8);border-radius:12px;border:1px solid rgba(255,255,255,0.05);">
          <span style="display:block;font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;">SEO Diagnostic</span>
          <div style="font-size:17px;font-weight:900;color:#fff;">${score} / 100 <span style="font-size:10px;background:rgba(16,185,129,0.2);color:#34d399;padding:2px 6px;border-radius:6px;">A'lo SEO</span></div>
        </div>
      </div>
    `;
      if (channelHeader.nextSibling) {
        channelHeader.parentNode?.insertBefore(card, channelHeader.nextSibling);
      } else {
        channelHeader.parentNode?.appendChild(card);
      }
      const actionButtons = document.querySelector("ytd-tabbed-page-header #buttons") || document.querySelector("#inner-header-container #buttons") || document.querySelector("#channel-header #buttons") || document.querySelector("#subscribe-button");
      if (actionButtons && !document.getElementById(VIEW_STATS_BTN_ID)) {
        const viewBtn = document.createElement("button");
        viewBtn.id = VIEW_STATS_BTN_ID;
        viewBtn.style.cssText = `
        margin-left: 8px !important;
        padding: 8px 16px !important;
        border-radius: 18px !important;
        background: linear-gradient(135deg, #0284c7, #0369a1) !important;
        color: #fff !important;
        font-size: 12px !important;
        font-weight: 800 !important;
        border: none !important;
        cursor: pointer !important;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.4) !important;
      `;
        viewBtn.textContent = "\u26A1 View channel stats (TubePilot)";
        viewBtn.onclick = () => {
          card.scrollIntoView({ behavior: "smooth", block: "center" });
        };
        actionButtons.parentNode?.insertBefore(viewBtn, actionButtons.nextSibling);
      }
    }
    function injectVideoBadges() {
      const videoItems = document.querySelectorAll(
        "ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer"
      );
      videoItems.forEach((item, index) => {
        if (item.querySelector(".tp-video-badge-container")) return;
        const dismissible = item.querySelector("#dismissible") || item.querySelector("#details") || item;
        const metaBlock = item.querySelector("#details #meta") || item.querySelector("#metadata") || item.querySelector(".ytd-video-meta-block") || item.querySelector("#meta");
        if (metaBlock) {
          const badgeContainer = document.createElement("div");
          badgeContainer.className = "tp-video-badge-container";
          badgeContainer.style.cssText = `
          display: flex !important;
          align-items: center !important;
          flex-wrap: wrap !important;
          gap: 6px !important;
          margin-top: 8px !important;
          z-index: 5 !important;
        `;
          const itemVph = 180 + index * 47 % 360 + " VPH";
          const itemSeo = 78 + index * 7 % 21 + "/100";
          badgeContainer.innerHTML = `
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(245,158,11,0.18);border:1px solid rgba(245,158,11,0.45);color:#fbbf24;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot AI Real-time Views Velocity">
            <span>\u26A1 ${itemVph}</span>
          </div>
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(16,185,129,0.18);border:1px solid rgba(16,185,129,0.45);color:#34d399;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot SEO Score">
            <span>\u{1F3AF} SEO: ${itemSeo}</span>
          </div>
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(56,189,248,0.18);border:1px solid rgba(56,189,248,0.45);color:#38bdf8;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot AI Teglar va Tahlil">
            <span>\u{1F680} TubePilot AI</span>
          </div>
        `;
          badgeContainer.onclick = (e) => {
            e.stopPropagation();
            e.preventDefault();
            window.open(`${API_BASE_URL}/uz/dashboard#channel-audit`, "_blank");
          };
          metaBlock.appendChild(badgeContainer);
        }
      });
    }
    function detectCurrentChannel() {
      const pathParts = window.location.pathname.split("/").filter(Boolean);
      const firstPart = pathParts[0] || "";
      if (firstPart.startsWith("@")) {
        return { handle: firstPart };
      }
      const headerTitle = document.querySelector("ytd-tabbed-page-header #channel-name yt-formatted-string")?.textContent?.trim() || document.querySelector("#page-header #channel-name")?.textContent?.trim() || document.querySelector("ytd-channel-name yt-formatted-string")?.textContent?.trim();
      const headerHandle = document.querySelector("ytd-tabbed-page-header #channel-handle")?.textContent?.trim() || document.querySelector("#page-header #channel-tag")?.textContent?.trim();
      if (headerHandle) {
        return { handle: headerHandle.startsWith("@") ? headerHandle : `@${headerHandle}`, title: headerTitle || void 0 };
      }
      if (headerTitle) {
        return { title: headerTitle };
      }
      return {};
    }
    function renderAll() {
      injectAlwaysVisibleBadge();
      injectTopMasthead();
      injectChannelStatsCard();
      injectVideoBadges();
    }
    let lastSyncedQuery = "";
    async function syncLiveData() {
      try {
        const connRes = await sendMessagePromise({ type: "FETCH_CONNECTED_CHANNEL" });
        if (connRes?.success && connRes?.data?.channel?.title) {
          const ch = connRes.data.channel;
          channelData = {
            channelTitle: ch.title,
            channelHandle: ch.handle || "@channel",
            subscribers: ch.subscribers || "0",
            totalViews: ch.views || "0",
            videoCount: ch.videoCount || "0",
            overallScore: 89,
            grade: "B+",
            vph: { currentVph: "280 VPH", peakVph: "740 VPH" },
            monetization: {
              estimatedRpm: "$0.85",
              regionBadge: "\u{1F1FA}\u{1F1FF} Uzbekistan",
              projectedMonthlyMin: "$45",
              projectedMonthlyMax: "$380"
            }
          };
          renderAll();
        }
        const detected = detectCurrentChannel();
        const query = detected.handle || detected.title;
        if (query && query !== lastSyncedQuery) {
          lastSyncedQuery = query;
          const res = await sendMessagePromise({ type: "FETCH_AUDIT", query });
          if (res?.success && res.data?.data) {
            channelData = res.data.data;
            renderAll();
          }
        }
      } catch {
      }
    }
    function observe() {
      renderAll();
      syncLiveData();
      const observer = new MutationObserver(() => {
        renderAll();
      });
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });
      window.addEventListener("yt-navigate-finish", () => {
        setTimeout(renderAll, 200);
        setTimeout(syncLiveData, 400);
      });
      window.addEventListener("popstate", () => {
        setTimeout(renderAll, 200);
      });
      setInterval(renderAll, 1200);
    }
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", observe);
    } else {
      observe();
    }
  })();
})();
//# sourceMappingURL=content.js.map
