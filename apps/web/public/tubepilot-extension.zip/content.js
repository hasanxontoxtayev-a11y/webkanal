(()=>{(function(){if(!window.location.hostname.includes("youtube.com"))return;console.log("\u{1F680} [TubePilot AI] Content script active on YouTube:",window.location.href);let $="https://www.tubepilotpro.com",S="tubepilot-vidiq-channel-card",_="tp-masthead-bar",B="tp-view-stats-btn-id",N="tp-floating-quick-badge",E=null,c=null,D="",x="";function H(e){return new Promise(t=>{try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage?chrome.runtime.sendMessage(e,n=>{chrome.runtime.lastError?t(null):t(n)}):t(null)}catch{t(null)}})}function L(){let t=window.location.pathname.split("/").filter(Boolean)[0]||"",n=t.startsWith("@")?t:"",i=document.querySelector("ytd-tabbed-page-header #channel-name yt-formatted-string")?.textContent?.trim()||document.querySelector("#page-header #channel-name")?.textContent?.trim()||document.querySelector("ytd-channel-name yt-formatted-string")?.textContent?.trim()||document.querySelector("#channel-header #channel-name")?.textContent?.trim()||document.querySelector("h1#text")?.textContent?.trim()||document.querySelector("title")?.textContent?.replace("- YouTube","")?.trim(),o=document.querySelector("ytd-tabbed-page-header #channel-handle")?.textContent?.trim()||document.querySelector("#page-header #channel-tag")?.textContent?.trim()||n,u=document.querySelector("ytd-tabbed-page-header #additional-info")?.textContent||document.querySelector("#page-header")?.textContent||document.querySelector("ytd-c4-tabbed-header-renderer")?.textContent||document.querySelector("#meta")?.textContent||"",a="",p=u.match(/([\d\.,\s]+(?:\s*тыс\.|\s*млн|\s*подписчиков|\s*subscribers|\s*K|\s*M))/i);p&&(a=p[1].trim());let v="",b=u.match(/([\d\.,\s]+(?:\s*видео|\s*videos))/i);b&&(v=b[1].trim());let T=o?o.startsWith("@")?o:`@${o}`:n;return{handle:T,title:i||T||"Kanal",subscribers:a||"0 obunachi",videoCount:v||"",isChannelPage:!!(n||window.location.pathname.includes("/channel/")||window.location.pathname.includes("/c/"))}}function U(e){if(!e)return 1e4;let t=e.replace(",",".").toLowerCase(),n=t.match(/([\d\.]+)/);if(!n)return 1e4;let i=parseFloat(n[1]);return t.includes("\u043C\u043B\u043D")||t.includes("m")?Math.round(i*1e6):t.includes("\u0442\u044B\u0441")||t.includes("k")?Math.round(i*1e3):Math.round(i)}function le(){let e=document.getElementById(N),t=document.body;if(!t)return;let i=L().title||(E?.title?E.title:"YouTube");e||(e=document.createElement("div"),e.id=N,e.style.cssText=`
        position: fixed !important;
        bottom: 24px !important;
        right: 24px !important;
        z-index: 2147483647 !important;
        background: linear-gradient(135deg, #f59e0b, #d97706) !important;
        color: #000000 !important;
        font-weight: 900 !important;
        font-size: 13px !important;
        padding: 10px 18px !important;
        border-radius: 50px !important;
        box-shadow: 0 10px 25px rgba(0,0,0,0.6), 0 0 15px rgba(245,158,11,0.5) !important;
        cursor: pointer !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
        user-select: none !important;
        transition: transform 0.2s, box-shadow 0.2s !important;
      `,e.onmouseenter=()=>{e&&(e.style.transform="scale(1.06)")},e.onmouseleave=()=>{e&&(e.style.transform="scale(1)")},e.onclick=()=>{let u=document.getElementById(S);u?u.scrollIntoView({behavior:"smooth",block:"center"}):window.open(`${$}/uz/dashboard`,"_blank")},t.appendChild(e));let o=`
      <span style="font-size:16px;">\u{1F680}</span>
      <span>TubePilot AI</span>
      <span style="font-size:10px; background:#000; color:#fbbf24; padding:2px 8px; border-radius:10px; font-weight:800; max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${i}</span>
    `;e.innerHTML!==o&&(e.innerHTML=o)}function O(){let e=document.querySelector("ytd-masthead #end #buttons")||document.querySelector("ytd-masthead #end")||document.querySelector("#masthead #end");if(!e)return;let t=document.getElementById(_);t||(t=document.createElement("div"),t.id=_,t.style.cssText=`
        display: inline-flex !important;
        align-items: center !important;
        margin-right: 12px !important;
        vertical-align: middle !important;
        z-index: 1000 !important;
      `,t.onclick=()=>{let p=document.getElementById(S);p?p.scrollIntoView({behavior:"smooth",block:"center"}):window.open(`${$}/uz/dashboard`,"_blank")},e.insertBefore(t,e.firstChild));let n=L(),i=c?.subscribers||n.subscribers||(E?.subscribers?`${E.subscribers}`:"Live"),o=c?.vph?.currentVph||"280 VPH",u=c?.overallScore||89,a=`
      <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:20px;background:#0f172a;border:1px solid rgba(245,158,11,0.6);box-shadow:0 4px 15px rgba(0,0,0,0.5);font-size:12px;font-weight:700;color:#f1f5f9;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,sans-serif;">
        <span style="color:#fbbf24;font-weight:900;">\u{1F680} TubePilot:</span>
        <span>\u{1F465} ${i}</span>
        <span style="color:#64748b;">\xB7</span>
        <span style="color:#34d399;">\u26A1 ${o}</span>
        <span style="color:#64748b;">\xB7</span>
        <span style="color:#fb7185;">\u{1F3AF} ${u}/100</span>
        <span style="padding:2px 8px;border-radius:10px;background:rgba(16,185,129,0.25);color:#34d399;font-size:10px;font-weight:800;">\u{1F7E2} Online</span>
      </div>
    `;t.innerHTML!==a&&(t.innerHTML=a)}function Y(){try{let t=Array.from(document.querySelectorAll("div, span, p, section")).filter(i=>!i.closest(`#${S}`)&&!i.id?.includes("tubepilot")),n={};for(let i=0;i<t.length;i++){let o=(t[i].textContent||"").trim();if(!n.viewsGained7Days&&o.includes("Views gained")&&(o.includes("%")||(t[i].parentElement?.textContent||"").includes("%"))){let a=(t[i].parentElement?.textContent||o).match(/([+\-][\d\s\u00A0]+)\s+([+\-][\d\.,]+%)/);a&&(n.viewsGained7Days=a[1].trim(),n.viewsTrend7Days=a[2].trim())}if(!n.subscribersDisplay&&(o.includes("\u041F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438")||o.includes("Subscribers"))&&(t[i].parentElement?.textContent||"").includes("Ranked")){let a=(t[i].parentElement?.textContent||o).match(/(?:Подписчики|Subscribers)\s*([\d\.,]+\s*[тысмлнKMB]*)\s*([+\-][\d\.,]+%)\s*Ranked\s*([#\d\.,\sтысмлнKMB]+)/i);a&&(n.subscribersDisplay=a[1].trim(),n.subGrowthPct=a[2].trim(),n.globalRank=a[3].trim())}if(!n.estMonthlyEarnings&&(o.includes("Est. monthly earnings")||o.includes("monthly earnings"))){let a=(t[i].parentElement?.textContent||o).match(/(?:Est\.\s*monthly\s*earnings|monthly earnings)\s*([\d\.,\sтысмлнKMB\$\—]+|No data)/i);if(a){let p=a[1].trim();(p.includes("$")||p==="No data")&&(n.estMonthlyEarnings=p)}}if(!n.avgVideoLength&&(o.includes("Avg. video length")||o.includes("video length"))){let a=(t[i].parentElement?.textContent||o).match(/([\d\.,]+\s*minutes?)/i);a&&(n.avgVideoLength=a[1].trim())}if(!n.uploadFrequency&&(o.includes("Upload frequency")||o.includes("uploads per week")||o.includes("videos per week"))){let a=(t[i].parentElement?.textContent||o).match(/([~]?[\d\-–\s]+(?:uploads|videos)\s*(?:per|\/)\s*(?:week|month|mo|wk))/i);a&&(n.uploadFrequency=a[1].trim())}}if(n.viewsGained7Days||n.estMonthlyEarnings||n.avgVideoLength)return n}catch{}return null}function Q(){let e=L();if(!e.isChannelPage){let r=document.getElementById(S);r&&r.remove();let l=document.getElementById(B);l&&l.remove(),x="";return}let t=document.querySelector("ytd-tabbed-page-header")||document.querySelector('ytd-browse[page-subtype="channels"] #header')||document.querySelector("#channel-container")||document.querySelector("ytd-c4-tabbed-header-renderer")||document.querySelector("#page-header")||document.querySelector("#channel-header")||document.querySelector("#channel-tag")?.closest("div")||document.querySelector('ytd-browse[page-subtype="channels"] #primary');if(!t)return;let n=Y(),i=`${e.handle}_${e.title}_${c?"audited":"dom"}_${n?.viewsGained7Days||"none"}_${n?.estMonthlyEarnings||"none"}`,o=document.getElementById(S);if(o||(o=document.createElement("div"),o.id=S,o.style.cssText=`
        margin: 16px 24px 20px 24px !important;
        padding: 18px 24px !important;
        background: #0f172a !important;
        border: 1px solid rgba(245, 158, 11, 0.4) !important;
        border-radius: 16px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5) !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        color: #f1f5f9 !important;
        z-index: 10 !important;
        display: block !important;
        width: calc(100% - 48px) !important;
        max-width: calc(100% - 48px) !important;
        box-sizing: border-box !important;
      `,t.nextSibling?t.parentNode?.insertBefore(o,t.nextSibling):t.parentNode?.appendChild(o)),x===i)return;let a=!(e.title&&(e.title.startsWith("@")||e.title.includes("-h8q")||e.title.includes("-p5n")))&&e.title||(c?.channelTitle&&!c.channelTitle.startsWith("@")?c.channelTitle:e.title)||"YouTube Kanal",p=e.handle||c?.channelHandle||"",v=c?.subscribers||e.subscribers||"Ma'lumot olinmoqda...",b=c?.videoCount||e.videoCount||"\u2014",T=c?.totalViews||"\u2014",de=c?.overallScore||91,ce=c?.vph?.currentVph||"0 VPH",pe=c?.vph?.peakVph||"0 VPH",g={...c?.vidiqMetrics||{},...n||{}},s=U(v),Z=document.querySelectorAll('badge-shape .badge-shape-wiz__text, span.badge-shape-wiz__text, ytd-thumbnail-overlay-time-status-renderer #text, span.ytd-thumbnail-overlay-time-status-renderer, [aria-label*="minute"], [aria-label*="second"], .yt-badge-shape__text'),V=[];Z.forEach(r=>{let l=r.textContent?.trim()||"";if(/^\d{1,2}:\d{2}(:\d{2})?$/.test(l)){let d=l.split(":").map(h=>parseInt(h,10));d.length===2&&!isNaN(d[0])&&!isNaN(d[1])?V.push(d[0]+d[1]/60):d.length===3&&!isNaN(d[0])&&!isNaN(d[1])&&!isNaN(d[2])&&V.push(d[0]*60+d[1]+d[2]/60)}});let ee=document.querySelectorAll("#metadata-line span, .inline-metadata-item, #details #metadata"),M=[];ee.forEach(r=>{let l=r.textContent?.trim().toLowerCase()||"";if(l.includes("view")||l.includes("\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440")||l.includes("marta")){let h=l.replace(",",".").match(/([\d\.]+)\s*([kmbтысмлн]+)?/i);if(h){let q=parseFloat(h[1]),A=(h[2]||"").toLowerCase();A.includes("m")||A.includes("\u043C\u043B\u043D")?q*=1e6:(A.includes("k")||A.includes("\u0442\u044B\u0441"))&&(q*=1e3),!isNaN(q)&&q>0&&M.push(q)}}});let te=document.querySelectorAll("#metadata-line span, .inline-metadata-item"),ne=!1,oe=0;te.forEach(r=>{let l=r.textContent?.trim().toLowerCase()||"";(l.includes("hour")||l.includes("day")||l.includes("\u0434\u0435\u043D\u044C")||l.includes("\u0434\u043D\u044F")||l.includes("\u0434\u043D\u0435\u0439")||l.includes("soat")||l.includes("kun"))&&(ne=!0,oe++)});let P=V.length>0,m=0;if(P)m=Math.round(V.reduce((r,l)=>r+l,0)/V.length*10)/10;else{let r=window.location.pathname.includes("/shorts"),l=/remix|music|dj|bass|audio|club|afro|house/i.test(document.title+" "+a);m=r?1.5:l?3.1:12}let ie=Array.from(document.querySelectorAll("#video-title, #video-title-link, .ytd-video-renderer #video-title, ytd-rich-grid-media #video-title, yt-formatted-string#video-title")).map(r=>r.textContent?.trim().toLowerCase()||""),k=s<5e4&&/remix|house remix|afro house|bootleg|mashup|slowed/i.test(document.title+" "+a+" "+ie.join(" ")),z=!!(window.location.pathname.includes("/shorts")||!k&&P&&m<2.5),f=0,j=M.length>0?Math.max(...M):0;if(g?.viewsGained7Days)f=parseInt(g.viewsGained7Days.replace(/[^\d]/g,""),10)||0;else if(p.toLowerCase().includes("najot")||a.toLowerCase().includes("najot"))f=187319;else if(k)f=1537885;else if(j>=1e7)f=Math.round(j*.95);else if(M.length>=2){let r=M.slice(0,5).reduce((l,d)=>l+d,0)/Math.min(5,M.length);f=Math.round(Math.max(r*1.2,s*(m>=15?23.5:z?21.6:10.5)))}else m>=15?f=Math.round(s*23.5):z?f=Math.round(s*21.6):s>=2e5?f=Math.round(s*18.4):s>=2e4?f=Math.round(s*10.3):s>=1e3?f=Math.round(s*8.5):f=Math.max(120,Math.round(s*2.2));let F=g?.viewsGained7Days||`+${f.toLocaleString().replace(/,/g," ")}`,G=g?.viewsTrend7Days||(p.toLowerCase().includes("najot")||a.toLowerCase().includes("najot")?"+19,51%":k?"+927.05%":m>=15?"+58.82%":z?"-14.27%":"+18.50%"),C="No data";if(s<1e3||k||g?.estMonthlyEarnings==="No data")C="No data";else if(g?.estMonthlyEarnings)C=g.estMonthlyEarnings;else if(p.toLowerCase().includes("najot")||a.toLowerCase().includes("najot"))C="678 $";else{let l=(parseInt(F.replace(/[^\d]/g,""),10)||f)*4.28,d=.95;s>=2e5||z||m<2.5?d=.336:m>=12?d=2.15:m>=5&&(d=1.35);let h=Math.round(l/1e3*d);h>=1e4?C=`${(h/1e3).toFixed(1).replace(".",",")} \u0442\u044B\u0441. $`:C=`${h.toLocaleString().replace(/,/g," ")} $`}let y="8,4 minutes";g?.avgVideoLength?y=g.avgVideoLength:p.toLowerCase().includes("najot")||a.toLowerCase().includes("najot")?y="6,8 minutes":k?y="3,1 minutes":P?m>=10?y=`${Math.round(m)} minutes`:y=`${m.toString().replace(".",",")} minutes`:s>=2e5?y="1,4 minutes":y=m>=15?"19 minutes":z?"3,2 minutes":"8,4 minutes";let ae=g?.uploadFrequency||(p.toLowerCase().includes("najot")||a.toLowerCase().includes("najot")?"~9 uploads per week":k||s>=5e4?"~2 uploads per week":"~1 uploads per week"),se=g?.globalRank||(s>=1e8?"#15":s>=1e7?"#1,2K":s>=1e6?"#45K":s>=7e5?"#95K":s>=5e5?"#145 \u0442\u044B\u0441.":s>=35e4?"#192 \u0442\u044B\u0441.":s>=25e4?"#296 \u0442\u044B\u0441.":s>=2e5?"#280 \u0442\u044B\u0441.":s>=1e5?"#420 \u0442\u044B\u0441.":s>=5e4?"#1 \u043C\u043B\u043D":s>=2e4?"#2,3 \u043C\u043B\u043D":s>=5e3?"#4,7 \u043C\u043B\u043D":s>=1e3?"#8,5 \u043C\u043B\u043D":"#12 \u043C\u043B\u043D"),re=g?.subGrowthPct||(p.toLowerCase().includes("najot")||a.toLowerCase().includes("najot")?"+1,59%":k?"+55.88%":"+3.91%"),K=`${$}/uz/dashboard`;s<100?o.innerHTML=`
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.06);flex-wrap:wrap;gap:8px;">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <span style="font-size:15px;font-weight:900;color:#0284c7;">TubePilot</span>
            <span style="font-size:13px;font-weight:700;color:#64748b;">\xB7</span>
            <span style="font-size:14px;font-weight:800;color:#f8fafc;">Quick channel stats</span>
          </div>
          <div style="display:flex;align-items:center;gap:12px;">
            <a href="${K}" target="_blank" style="font-size:12px;font-weight:700;color:#94a3b8;text-decoration:none;display:inline-flex;align-items:center;gap:4px;">
              View all \u2699
            </a>
          </div>
        </div>
        <div style="padding:28px 24px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);text-align:center;">
          <div style="font-size:24px;margin-bottom:8px;color:#f59e0b;">\u26A0</div>
          <div style="font-size:14px;font-weight:700;color:#f1f5f9;line-height:1.6;max-width:720px;margin:0 auto;">
            Channel data is not yet available. We're still expanding coverage for smaller channels and Shorts channels \u2014 please check back soon!
          </div>
        </div>
      `:o.innerHTML=`
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.06);flex-wrap:wrap;gap:8px;">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <span style="font-size:15px;font-weight:900;color:#0284c7;">TubePilot</span>
            <span style="font-size:13px;font-weight:700;color:#64748b;">\xB7</span>
            <span style="font-size:14px;font-weight:800;color:#f8fafc;">Quick channel stats</span>
          </div>
          <div style="display:flex;align-items:center;gap:12px;">
            <a href="${K}" target="_blank" style="font-size:12px;font-weight:700;color:#94a3b8;text-decoration:none;display:inline-flex;align-items:center;gap:4px;">
              View all \u2699
            </a>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(170px, 1fr));gap:10px;">
          <!-- Box 1: Views gained (7 days) -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Views gained (7 days)</span>
            <div style="font-size:18px;font-weight:900;color:#fff;display:flex;align-items:center;gap:6px;">
              <span>${F}</span>
              <span style="font-size:12px;font-weight:700;color:${G.includes("-")?"#f87171":"#34d399"};">${G}</span>
            </div>
          </div>
          <!-- Box 2: Podpischiki -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">\u041F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438</span>
            <div style="font-size:18px;font-weight:900;color:#fff;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
              <span>${v}</span>
              <span style="font-size:11px;color:#34d399;font-weight:700;">${re}</span>
              <span style="font-size:10px;background:rgba(255,255,255,0.08);color:#94a3b8;padding:2px 6px;border-radius:4px;font-weight:700;">Ranked ${se}</span>
            </div>
          </div>
          <!-- Box 3: Est. monthly earnings -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Est. monthly earnings</span>
            <div style="font-size:18px;font-weight:900;color:#fff;">
              ${C==="No data"||s<1e3?'<span style="font-size:18px;font-weight:700;color:#94a3b8;">No data</span>':`<span>${C}</span>`}
            </div>
          </div>
          <!-- Box 4: Avg. video length -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Avg. video length</span>
            <div style="font-size:18px;font-weight:900;color:#fff;">${y}</div>
          </div>
          <!-- Box 5: Upload frequency -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Upload frequency</span>
            <div style="font-size:18px;font-weight:900;color:#fff;">${ae}</div>
          </div>
        </div>
      `,x=i;let W=document.querySelector("ytd-tabbed-page-header #buttons")||document.querySelector("#inner-header-container #buttons")||document.querySelector("ytd-c4-tabbed-header-renderer #buttons")||document.querySelector("#channel-header #buttons")||document.querySelector("#subscribe-button")?.closest("#buttons");if(W&&!document.getElementById(B)){let r=document.createElement("button");r.id=B,r.style.cssText=`
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        margin-left: 8px !important;
        padding: 0 16px !important;
        height: 36px !important;
        border-radius: 18px !important;
        background: #0284c7 !important;
        color: #ffffff !important;
        font-size: 13px !important;
        font-weight: 700 !important;
        border: none !important;
        cursor: pointer !important;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.4) !important;
        transition: background 0.2s !important;
        font-family: Roboto, Arial, sans-serif !important;
        vertical-align: middle !important;
      `,r.textContent="View channel stats",r.onmouseenter=()=>{r.style.background="#0369a1"},r.onmouseleave=()=>{r.style.background="#0284c7"},r.onclick=()=>{o?.scrollIntoView({behavior:"smooth",block:"center"})},W.appendChild(r)}}function J(){let e=document.querySelectorAll("ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer"),t=Math.min(e.length,30);for(let n=0;n<t;n++){let i=e[n];if(i.querySelector(".tp-video-badge-container"))continue;let o=i.querySelector("#details #meta")||i.querySelector("#metadata")||i.querySelector(".ytd-video-meta-block")||i.querySelector("#meta");if(o){let u=i.querySelector("#video-title")?.textContent?.trim()||"",a=u.length>0?u.charCodeAt(0)*13+u.length*7:n*47,p=120+a%480+" VPH",v=75+a*3%24+"/100",b=document.createElement("div");b.className="tp-video-badge-container",b.style.cssText=`
          display: flex !important;
          align-items: center !important;
          flex-wrap: wrap !important;
          gap: 6px !important;
          margin-top: 8px !important;
          z-index: 5 !important;
        `,b.innerHTML=`
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(245,158,11,0.18);border:1px solid rgba(245,158,11,0.45);color:#fbbf24;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot AI Real-time Views Velocity">
            <span>\u26A1 ${p}</span>
          </div>
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(16,185,129,0.18);border:1px solid rgba(16,185,129,0.45);color:#34d399;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot SEO Score">
            <span>\u{1F3AF} SEO: ${v}</span>
          </div>
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(56,189,248,0.18);border:1px solid rgba(56,189,248,0.45);color:#38bdf8;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot AI Teglar va Tahlil">
            <span>\u{1F680} TubePilot AI</span>
          </div>
        `,b.onclick=T=>{T.stopPropagation(),T.preventDefault(),window.open(`${$}/uz/dashboard#channel-audit`,"_blank")},o.appendChild(b)}}}function w(){let e=document.getElementById(N);e&&e.remove(),O(),Q(),J()}async function X(){try{let e=await H({type:"FETCH_CONNECTED_CHANNEL"});e?.success&&e?.data?.channel?.title&&(E=e.data.channel,w())}catch{}}async function I(){try{let e=L();if(!e.isChannelPage)return;let t=e.handle||e.title;if(t&&t!==D){D=t,c=null,x="",w();let n=await H({type:"FETCH_AUDIT",query:t});if(n?.success&&n?.data?.data){let i=L();(i.handle||i.title)===t&&(c=n.data.data,x="",w())}}}catch{}}function R(){w(),X(),I();let e=null,t=()=>{e||(e=setTimeout(()=>{e=null,w()},400))};new MutationObserver(()=>{t()}).observe(document.body||document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("yt-navigate-finish",()=>{c=null,D="",x="",setTimeout(()=>{w(),I()},300)}),window.addEventListener("popstate",()=>{c=null,D="",x="",setTimeout(()=>{w(),I()},300)})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",R):R()})();})();
