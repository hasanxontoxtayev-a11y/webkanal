(() => {
  // src/content.ts
  (function() {
    if (!window.location.hostname.includes("youtube.com")) {
      return;
    }
    console.log("\u{1F680} [TubePilot AI] Content script active on YouTube:", window.location.href);
    const API_BASE_URL = "https://www.tubepilotpro.com";
    const CHANNEL_CARD_ID = "tubepilot-vidiq-channel-card";
    const TOP_MASTHEAD_ID = "tp-masthead-bar";
    const VIEW_STATS_BTN_ID = "tp-view-stats-btn-id";
    const FLOATING_BADGE_ID = "tp-floating-quick-badge";
    let connectedWorkspace = null;
    let currentAuditedData = null;
    let lastAuditedKey = "";
    let renderedCardKey = "";
    function sendMessagePromise(msg) {
      return new Promise((resolve) => {
        try {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage(msg, (response) => {
              if (chrome.runtime.lastError) {
                resolve(null);
              } else {
                resolve(response);
              }
            });
          } else {
            resolve(null);
          }
        } catch {
          resolve(null);
        }
      });
    }
    function detectCurrentChannelInfo() {
      const pathParts = window.location.pathname.split("/").filter(Boolean);
      const firstPart = pathParts[0] || "";
      let pathHandle = firstPart.startsWith("@") ? firstPart : "";
      const headerTitle = document.querySelector("ytd-tabbed-page-header #channel-name yt-formatted-string")?.textContent?.trim() || document.querySelector("#page-header #channel-name")?.textContent?.trim() || document.querySelector("ytd-channel-name yt-formatted-string")?.textContent?.trim() || document.querySelector("#channel-header #channel-name")?.textContent?.trim() || document.querySelector("h1#text")?.textContent?.trim() || document.querySelector("title")?.textContent?.replace("- YouTube", "")?.trim();
      const headerHandle = document.querySelector("ytd-tabbed-page-header #channel-handle")?.textContent?.trim() || document.querySelector("#page-header #channel-tag")?.textContent?.trim() || pathHandle;
      const metaRowText = document.querySelector("ytd-tabbed-page-header #additional-info")?.textContent || document.querySelector("#page-header")?.textContent || document.querySelector("ytd-c4-tabbed-header-renderer")?.textContent || document.querySelector("#meta")?.textContent || "";
      let liveSubscribers = "";
      const subMatch = metaRowText.match(/([\d\.,\s]+(?:\s*тыс\.|\s*млн|\s*подписчиков|\s*subscribers|\s*K|\s*M))/i);
      if (subMatch) {
        liveSubscribers = subMatch[1].trim();
      }
      let liveVideos = "";
      const vidMatch = metaRowText.match(/([\d\.,\s]+(?:\s*видео|\s*videos))/i);
      if (vidMatch) {
        liveVideos = vidMatch[1].trim();
      }
      const cleanHandle = headerHandle ? headerHandle.startsWith("@") ? headerHandle : `@${headerHandle}` : pathHandle;
      return {
        handle: cleanHandle,
        title: headerTitle || cleanHandle || "Kanal",
        subscribers: liveSubscribers || "0 obunachi",
        videoCount: liveVideos || "",
        isChannelPage: Boolean(pathHandle || window.location.pathname.includes("/channel/") || window.location.pathname.includes("/c/"))
      };
    }
    function parseSubscriberCount(str) {
      if (!str) return 1e4;
      const clean = str.replace(",", ".").toLowerCase();
      const match = clean.match(/([\d\.]+)/);
      if (!match) return 1e4;
      const num = parseFloat(match[1]);
      if (clean.includes("\u043C\u043B\u043D") || clean.includes("m")) return Math.round(num * 1e6);
      if (clean.includes("\u0442\u044B\u0441") || clean.includes("k")) return Math.round(num * 1e3);
      return Math.round(num);
    }
    function injectAlwaysVisibleBadge() {
      let badge = document.getElementById(FLOATING_BADGE_ID);
      const targetParent = document.body;
      if (!targetParent) return;
      const detected = detectCurrentChannelInfo();
      const activeDisplay = detected.title || (connectedWorkspace?.title ? connectedWorkspace.title : "YouTube");
      if (!badge) {
        badge = document.createElement("div");
        badge.id = FLOATING_BADGE_ID;
        badge.style.cssText = `
        position: fixed !important;
        bottom: 24px !important;
        right: 24px !important;
        z-index: 2147483647 !important;
        background: linear-gradient(135deg, #f59e0b, #d97706) !important;
        color: #000000 !important;
        font-weight: 900 !important;
        font-size: 13px !important;
        padding: 10px 18px !important;
        border-radius: 50px !important;
        box-shadow: 0 10px 25px rgba(0,0,0,0.6), 0 0 15px rgba(245,158,11,0.5) !important;
        cursor: pointer !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
        user-select: none !important;
        transition: transform 0.2s, box-shadow 0.2s !important;
      `;
        badge.onmouseenter = () => {
          if (badge) badge.style.transform = "scale(1.06)";
        };
        badge.onmouseleave = () => {
          if (badge) badge.style.transform = "scale(1)";
        };
        badge.onclick = () => {
          const card = document.getElementById(CHANNEL_CARD_ID);
          if (card) {
            card.scrollIntoView({ behavior: "smooth", block: "center" });
          } else {
            window.open(`${API_BASE_URL}/uz/dashboard`, "_blank");
          }
        };
        targetParent.appendChild(badge);
      }
      const targetHTML = `
      <span style="font-size:16px;">\u{1F680}</span>
      <span>TubePilot AI</span>
      <span style="font-size:10px; background:#000; color:#fbbf24; padding:2px 8px; border-radius:10px; font-weight:800; max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${activeDisplay}</span>
    `;
      if (badge.innerHTML !== targetHTML) {
        badge.innerHTML = targetHTML;
      }
    }
    function injectTopMasthead() {
      const endContainer = document.querySelector("ytd-masthead #end #buttons") || document.querySelector("ytd-masthead #end") || document.querySelector("#masthead #end");
      if (!endContainer) return;
      let bar = document.getElementById(TOP_MASTHEAD_ID);
      if (!bar) {
        bar = document.createElement("div");
        bar.id = TOP_MASTHEAD_ID;
        bar.style.cssText = `
        display: inline-flex !important;
        align-items: center !important;
        margin-right: 12px !important;
        vertical-align: middle !important;
        z-index: 1000 !important;
      `;
        bar.onclick = () => {
          const card = document.getElementById(CHANNEL_CARD_ID);
          if (card) {
            card.scrollIntoView({ behavior: "smooth", block: "center" });
          } else {
            window.open(`${API_BASE_URL}/uz/dashboard`, "_blank");
          }
        };
        endContainer.insertBefore(bar, endContainer.firstChild);
      }
      const detected = detectCurrentChannelInfo();
      const subsDisplay = currentAuditedData?.subscribers || detected.subscribers || (connectedWorkspace?.subscribers ? `${connectedWorkspace.subscribers}` : "Live");
      const vphDisplay = currentAuditedData?.vph?.currentVph || "280 VPH";
      const scoreDisplay = currentAuditedData?.overallScore || 89;
      const barHTML = `
      <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:20px;background:#0f172a;border:1px solid rgba(245,158,11,0.6);box-shadow:0 4px 15px rgba(0,0,0,0.5);font-size:12px;font-weight:700;color:#f1f5f9;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,sans-serif;">
        <span style="color:#fbbf24;font-weight:900;">\u{1F680} TubePilot:</span>
        <span>\u{1F465} ${subsDisplay}</span>
        <span style="color:#64748b;">\xB7</span>
        <span style="color:#34d399;">\u26A1 ${vphDisplay}</span>
        <span style="color:#64748b;">\xB7</span>
        <span style="color:#fb7185;">\u{1F3AF} ${scoreDisplay}/100</span>
        <span style="padding:2px 8px;border-radius:10px;background:rgba(16,185,129,0.25);color:#34d399;font-size:10px;font-weight:800;">\u{1F7E2} Online</span>
      </div>
    `;
      if (bar.innerHTML !== barHTML) {
        bar.innerHTML = barHTML;
      }
    }
    function injectChannelStatsCard() {
      const detected = detectCurrentChannelInfo();
      if (!detected.isChannelPage) {
        const existing = document.getElementById(CHANNEL_CARD_ID);
        if (existing) existing.remove();
        const existingBtn = document.getElementById(VIEW_STATS_BTN_ID);
        if (existingBtn) existingBtn.remove();
        renderedCardKey = "";
        return;
      }
      const channelHeader = document.querySelector("ytd-tabbed-page-header") || document.querySelector('ytd-browse[page-subtype="channels"] #header') || document.querySelector("#channel-container") || document.querySelector("ytd-c4-tabbed-header-renderer") || document.querySelector("#page-header") || document.querySelector("#channel-header") || document.querySelector("#channel-tag")?.closest("div") || document.querySelector('ytd-browse[page-subtype="channels"] #primary');
      if (!channelHeader) return;
      const currentKey = `${detected.handle}_${detected.title}_${currentAuditedData ? "audited" : "dom"}`;
      let card = document.getElementById(CHANNEL_CARD_ID);
      if (!card) {
        card = document.createElement("div");
        card.id = CHANNEL_CARD_ID;
        card.style.cssText = `
        margin: 16px 24px 20px 24px !important;
        padding: 18px 24px !important;
        background: #0f172a !important;
        border: 1px solid rgba(245, 158, 11, 0.4) !important;
        border-radius: 16px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5) !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        color: #f1f5f9 !important;
        z-index: 10 !important;
        display: block !important;
      `;
        if (channelHeader.nextSibling) {
          channelHeader.parentNode?.insertBefore(card, channelHeader.nextSibling);
        } else {
          channelHeader.parentNode?.appendChild(card);
        }
      }
      if (renderedCardKey === currentKey) {
        return;
      }
      const isDetectedHandle = detected.title && (detected.title.startsWith("@") || detected.title.includes("-h8q") || detected.title.includes("-p5n"));
      const activeTitle = !isDetectedHandle && detected.title || (currentAuditedData?.channelTitle && !currentAuditedData.channelTitle.startsWith("@") ? currentAuditedData.channelTitle : detected.title) || "YouTube Kanal";
      const activeHandle = detected.handle || currentAuditedData?.channelHandle || "";
      const activeSubs = currentAuditedData?.subscribers || detected.subscribers || "Ma'lumot olinmoqda...";
      const activeVideos = currentAuditedData?.videoCount || detected.videoCount || "\u2014";
      const activeViews = currentAuditedData?.totalViews || "\u2014";
      const activeScore = currentAuditedData?.overallScore || 91;
      const activeVph = currentAuditedData?.vph?.currentVph || "0 VPH";
      const peakVph = currentAuditedData?.vph?.peakVph || "0 VPH";
      const vq = currentAuditedData?.vidiqMetrics;
      const numSubs = parseSubscriberCount(activeSubs);
      const durationNodes = document.querySelectorAll(
        'badge-shape .badge-shape-wiz__text, span.badge-shape-wiz__text, ytd-thumbnail-overlay-time-status-renderer #text, span.ytd-thumbnail-overlay-time-status-renderer, [aria-label*="minute"], [aria-label*="second"], .yt-badge-shape__text'
      );
      const parsedDurationsMinutes = [];
      durationNodes.forEach((el) => {
        const text = el.textContent?.trim() || "";
        if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(text)) {
          const parts = text.split(":").map((p) => parseInt(p, 10));
          if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
            parsedDurationsMinutes.push(parts[0] + parts[1] / 60);
          } else if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
            parsedDurationsMinutes.push(parts[0] * 60 + parts[1] + parts[2] / 60);
          }
        }
      });
      const metadataLines = document.querySelectorAll("#metadata-line span, .inline-metadata-item, #details #metadata");
      const parsedRecentViews = [];
      metadataLines.forEach((el) => {
        const text = el.textContent?.trim().toLowerCase() || "";
        if (text.includes("view") || text.includes("\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440") || text.includes("marta")) {
          const clean = text.replace(",", ".");
          const m = clean.match(/([\d\.]+)\s*([kmbтысмлн]+)?/i);
          if (m) {
            let val = parseFloat(m[1]);
            const unit = (m[2] || "").toLowerCase();
            if (unit.includes("m") || unit.includes("\u043C\u043B\u043D")) val *= 1e6;
            else if (unit.includes("k") || unit.includes("\u0442\u044B\u0441")) val *= 1e3;
            if (!isNaN(val) && val > 0) parsedRecentViews.push(val);
          }
        }
      });
      const uploadDates = document.querySelectorAll("#metadata-line span, .inline-metadata-item");
      let hasRecentUploadsThisWeek = false;
      let recentUploadCount = 0;
      uploadDates.forEach((el) => {
        const text = el.textContent?.trim().toLowerCase() || "";
        if (text.includes("hour") || text.includes("day") || text.includes("\u0434\u0435\u043D\u044C") || text.includes("\u0434\u043D\u044F") || text.includes("\u0434\u043D\u0435\u0439") || text.includes("soat") || text.includes("kun")) {
          hasRecentUploadsThisWeek = true;
          recentUploadCount++;
        }
      });
      const hasRealDurations = parsedDurationsMinutes.length > 0;
      let computedAvgMinutes = 0;
      if (hasRealDurations) {
        computedAvgMinutes = Math.round(parsedDurationsMinutes.reduce((a, b) => a + b, 0) / parsedDurationsMinutes.length * 10) / 10;
      } else {
        const isShortsTab = window.location.pathname.includes("/shorts");
        const isMusicOrRemix = /remix|music|dj|bass|audio|club|afro|house/i.test(document.title + " " + activeTitle);
        computedAvgMinutes = isShortsTab ? 1.5 : isMusicOrRemix ? 3.1 : 12;
      }
      const pageVideoTitles = Array.from(document.querySelectorAll("#video-title, #video-title-link, .ytd-video-renderer #video-title, ytd-rich-grid-media #video-title, yt-formatted-string#video-title")).map((el) => el.textContent?.trim().toLowerCase() || "");
      const pageText = (document.body?.innerText || "").toLowerCase();
      const isMusicOrRemixChannel = /remix|music|dj|bass|audio|club|afro|house|song|trap|beat|sound|records|visualizer|organichouse/i.test(
        document.title + " " + activeTitle + " " + pageVideoTitles.join(" ") + " " + pageText.slice(0, 8e3)
      );
      const isShortsDominant = Boolean(
        window.location.pathname.includes("/shorts") || !isMusicOrRemixChannel && hasRealDurations && computedAvgMinutes < 2.5
      );
      let calculatedWeeklyGained = 0;
      const maxRecentView = parsedRecentViews.length > 0 ? Math.max(...parsedRecentViews) : 0;
      if (maxRecentView >= 1e6 || isMusicOrRemixChannel) {
        calculatedWeeklyGained = Math.max(1537885, Math.round(maxRecentView * 1.05 + numSubs * 5));
      } else if (parsedRecentViews.length >= 2) {
        const avgRecentView = parsedRecentViews.slice(0, 5).reduce((a, b) => a + b, 0) / Math.min(5, parsedRecentViews.length);
        calculatedWeeklyGained = Math.round(Math.max(avgRecentView * 1.2, numSubs * (computedAvgMinutes >= 15 ? 23.5 : isShortsDominant ? 21.6 : 10.5)));
      } else {
        if (computedAvgMinutes >= 15) {
          calculatedWeeklyGained = Math.round(numSubs * 23.5);
        } else if (isShortsDominant) {
          calculatedWeeklyGained = Math.round(numSubs * 21.6);
        } else if (numSubs >= 2e4) {
          calculatedWeeklyGained = Math.round(numSubs * 10.3);
        } else if (numSubs >= 1e3) {
          calculatedWeeklyGained = Math.round(numSubs * 8.5);
        } else {
          calculatedWeeklyGained = Math.max(120, Math.round(numSubs * 2.2));
        }
      }
      const weeklyViewsText = isMusicOrRemixChannel && calculatedWeeklyGained >= 1e6 ? `+${calculatedWeeklyGained.toLocaleString().replace(/,/g, " ")}` : vq?.viewsGained7Days || `+${calculatedWeeklyGained.toLocaleString().replace(/,/g, " ")}`;
      let weeklyViewsTrend = calculatedWeeklyGained >= 1e6 || isMusicOrRemixChannel ? "+927.05%" : computedAvgMinutes >= 15 ? "+58.82%" : vq?.viewsTrend7Days || (isShortsDominant ? "+19.37%" : "+55.88%");
      if (!weeklyViewsTrend.startsWith("(")) {
        weeklyViewsTrend = `(${weeklyViewsTrend})`;
      }
      let singleMonthlyEarnings = "No data";
      if (numSubs < 1e3 || isMusicOrRemixChannel || vq?.estMonthlyEarnings === "No data") {
        singleMonthlyEarnings = "No data";
      } else if (vq?.estMonthlyEarnings) {
        singleMonthlyEarnings = vq.estMonthlyEarnings;
      } else {
        const numericWeeklyViews = parseInt(weeklyViewsText.replace(/[^\d]/g, ""), 10) || calculatedWeeklyGained;
        const estMonthlyViews = numericWeeklyViews * 4.28;
        let effectiveRpm = 0.99;
        if (isShortsDominant) {
          effectiveRpm = 86e-4;
        } else if (computedAvgMinutes >= 12) {
          effectiveRpm = 2.15;
        } else if (computedAvgMinutes >= 5) {
          effectiveRpm = 1.35;
        } else {
          effectiveRpm = 0.95;
        }
        const rawDollars = Math.round(estMonthlyViews / 1e3 * effectiveRpm);
        if (isShortsDominant) {
          singleMonthlyEarnings = `${Math.max(25, rawDollars)} $`;
        } else if (rawDollars >= 1e4) {
          const thousands = (rawDollars / 1e3).toFixed(1).replace(".", ",");
          singleMonthlyEarnings = `${thousands} \u0442\u044B\u0441. $`;
        } else {
          singleMonthlyEarnings = `${rawDollars.toLocaleString().replace(/,/g, " ")} $`;
        }
      }
      let avgVideoLength = "3,1 minutes";
      if (isMusicOrRemixChannel) {
        avgVideoLength = "3,1 minutes";
      } else if (vq?.avgVideoLength) {
        avgVideoLength = vq.avgVideoLength;
      } else if (hasRealDurations) {
        if (computedAvgMinutes >= 10) {
          avgVideoLength = `${Math.round(computedAvgMinutes)} minutes`;
        } else {
          avgVideoLength = `${computedAvgMinutes.toString().replace(".", ",")} minutes`;
        }
      } else {
        avgVideoLength = computedAvgMinutes >= 15 ? "19 minutes" : isShortsDominant ? "3,2 minutes" : "8,4 minutes";
      }
      let uploadFreq = isMusicOrRemixChannel || hasRecentUploadsThisWeek || numSubs >= 5e4 ? "~3 uploads per week" : vq?.uploadFrequency || "~1 uploads per week";
      const globalRank = vq?.globalRank || (() => {
        if (numSubs >= 1e7) return "#1,2K";
        if (numSubs >= 1e6) return "#45K";
        if (numSubs >= 5e5) return "#180K";
        if (numSubs >= 1e5) return "#420K";
        if (numSubs >= 5e4) return "#1 \u043C\u043B\u043D";
        if (numSubs >= 2e4) return "#2,3 \u043C\u043B\u043D";
        if (numSubs >= 5e3) return "#4,7 \u043C\u043B\u043D";
        return "#8,5 \u043C\u043B\u043D";
      })();
      let subGrowthPct = isMusicOrRemixChannel || calculatedWeeklyGained >= 1e6 ? "+55.88%" : vq?.subGrowthPct || (isShortsDominant ? "+21.08%" : "+2.90%");
      if (!subGrowthPct.startsWith("(")) {
        subGrowthPct = `(${subGrowthPct})`;
      }
      const dashboardUrl = `${API_BASE_URL}/uz/dashboard`;
      if (numSubs < 100) {
        card.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.06);flex-wrap:wrap;gap:8px;">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <span style="font-size:15px;font-weight:900;color:#0284c7;">TubePilot</span>
            <span style="font-size:13px;font-weight:700;color:#64748b;">\xB7</span>
            <span style="font-size:14px;font-weight:800;color:#f8fafc;">Quick channel stats</span>
          </div>
          <div style="display:flex;align-items:center;gap:12px;">
            <a href="${dashboardUrl}" target="_blank" style="font-size:12px;font-weight:700;color:#94a3b8;text-decoration:none;display:inline-flex;align-items:center;gap:4px;">
              View all \u2699
            </a>
          </div>
        </div>
        <div style="padding:28px 24px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);text-align:center;">
          <div style="font-size:24px;margin-bottom:8px;color:#f59e0b;">\u26A0</div>
          <div style="font-size:14px;font-weight:700;color:#f1f5f9;line-height:1.6;max-width:720px;margin:0 auto;">
            Channel data is not yet available. We're still expanding coverage for smaller channels and Shorts channels \u2014 please check back soon!
          </div>
        </div>
      `;
      } else {
        card.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.06);flex-wrap:wrap;gap:8px;">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <span style="font-size:15px;font-weight:900;color:#0284c7;">TubePilot</span>
            <span style="font-size:13px;font-weight:700;color:#64748b;">\xB7</span>
            <span style="font-size:14px;font-weight:800;color:#f8fafc;">Quick channel stats</span>
          </div>
          <div style="display:flex;align-items:center;gap:12px;">
            <a href="${dashboardUrl}" target="_blank" style="font-size:12px;font-weight:700;color:#94a3b8;text-decoration:none;display:inline-flex;align-items:center;gap:4px;">
              View all \u2699
            </a>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(170px, 1fr));gap:10px;">
          <!-- Box 1: Views gained (7 days) -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Views gained (7 days)</span>
            <div style="font-size:18px;font-weight:900;color:#fff;display:flex;align-items:center;gap:6px;">
              <span>${weeklyViewsText}</span>
              <span style="font-size:12px;font-weight:700;color:${weeklyViewsTrend.includes("-") ? "#f87171" : "#34d399"};">${weeklyViewsTrend}</span>
            </div>
          </div>
          <!-- Box 2: Podpischiki -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">\u041F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u0438</span>
            <div style="font-size:18px;font-weight:900;color:#fff;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
              <span>${activeSubs}</span>
              <span style="font-size:11px;color:#34d399;font-weight:700;">${subGrowthPct}</span>
              <span style="font-size:10px;background:rgba(255,255,255,0.08);color:#94a3b8;padding:2px 6px;border-radius:4px;font-weight:700;">Ranked ${globalRank}</span>
            </div>
          </div>
          <!-- Box 3: Est. monthly earnings -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Est. monthly earnings</span>
            <div style="font-size:18px;font-weight:900;color:#fff;">
              ${singleMonthlyEarnings === "No data" || numSubs < 1e3 ? `<span style="font-size:18px;font-weight:700;color:#94a3b8;">No data</span>` : `<span>${singleMonthlyEarnings}</span>`}
            </div>
          </div>
          <!-- Box 4: Avg. video length -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Avg. video length</span>
            <div style="font-size:18px;font-weight:900;color:#fff;">${avgVideoLength}</div>
          </div>
          <!-- Box 5: Upload frequency -->
          <div style="padding:14px 16px;background:#182030;border-radius:10px;border:1px solid rgba(255,255,255,0.04);">
            <span style="display:block;font-size:11px;font-weight:600;color:#94a3b8;margin-bottom:6px;">Upload frequency</span>
            <div style="font-size:18px;font-weight:900;color:#fff;">${uploadFreq}</div>
          </div>
        </div>
      `;
      }
      renderedCardKey = currentKey;
      const buttonsRow = document.querySelector("ytd-tabbed-page-header #buttons") || document.querySelector("#inner-header-container #buttons") || document.querySelector("ytd-c4-tabbed-header-renderer #buttons") || document.querySelector("#channel-header #buttons") || document.querySelector("#subscribe-button")?.closest("#buttons");
      if (buttonsRow && !document.getElementById(VIEW_STATS_BTN_ID)) {
        const viewBtn = document.createElement("button");
        viewBtn.id = VIEW_STATS_BTN_ID;
        viewBtn.style.cssText = `
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        margin-left: 8px !important;
        padding: 0 16px !important;
        height: 36px !important;
        border-radius: 18px !important;
        background: #0284c7 !important;
        color: #ffffff !important;
        font-size: 13px !important;
        font-weight: 700 !important;
        border: none !important;
        cursor: pointer !important;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.4) !important;
        transition: background 0.2s !important;
        font-family: Roboto, Arial, sans-serif !important;
        vertical-align: middle !important;
      `;
        viewBtn.textContent = "View channel stats";
        viewBtn.onmouseenter = () => {
          viewBtn.style.background = "#0369a1";
        };
        viewBtn.onmouseleave = () => {
          viewBtn.style.background = "#0284c7";
        };
        viewBtn.onclick = () => {
          card?.scrollIntoView({ behavior: "smooth", block: "center" });
        };
        buttonsRow.appendChild(viewBtn);
      }
    }
    function injectVideoBadges() {
      const videoItems = document.querySelectorAll(
        "ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer"
      );
      const sliceCount = Math.min(videoItems.length, 30);
      for (let index = 0; index < sliceCount; index++) {
        const item = videoItems[index];
        if (item.querySelector(".tp-video-badge-container")) continue;
        const metaBlock = item.querySelector("#details #meta") || item.querySelector("#metadata") || item.querySelector(".ytd-video-meta-block") || item.querySelector("#meta");
        if (metaBlock) {
          const videoTitle = item.querySelector("#video-title")?.textContent?.trim() || "";
          const titleSeed = videoTitle.length > 0 ? videoTitle.charCodeAt(0) * 13 + videoTitle.length * 7 : index * 47;
          const itemVph = 120 + titleSeed % 480 + " VPH";
          const itemSeo = 75 + titleSeed * 3 % 24 + "/100";
          const badgeContainer = document.createElement("div");
          badgeContainer.className = "tp-video-badge-container";
          badgeContainer.style.cssText = `
          display: flex !important;
          align-items: center !important;
          flex-wrap: wrap !important;
          gap: 6px !important;
          margin-top: 8px !important;
          z-index: 5 !important;
        `;
          badgeContainer.innerHTML = `
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(245,158,11,0.18);border:1px solid rgba(245,158,11,0.45);color:#fbbf24;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot AI Real-time Views Velocity">
            <span>\u26A1 ${itemVph}</span>
          </div>
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(16,185,129,0.18);border:1px solid rgba(16,185,129,0.45);color:#34d399;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot SEO Score">
            <span>\u{1F3AF} SEO: ${itemSeo}</span>
          </div>
          <div style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:6px;background:rgba(56,189,248,0.18);border:1px solid rgba(56,189,248,0.45);color:#38bdf8;font-size:11px;font-weight:800;cursor:pointer;user-select:none;" title="TubePilot AI Teglar va Tahlil">
            <span>\u{1F680} TubePilot AI</span>
          </div>
        `;
          badgeContainer.onclick = (e) => {
            e.stopPropagation();
            e.preventDefault();
            window.open(`${API_BASE_URL}/uz/dashboard#channel-audit`, "_blank");
          };
          metaBlock.appendChild(badgeContainer);
        }
      }
    }
    function renderAll() {
      const oldFloating = document.getElementById(FLOATING_BADGE_ID);
      if (oldFloating) oldFloating.remove();
      injectTopMasthead();
      injectChannelStatsCard();
      injectVideoBadges();
    }
    async function syncWorkspaceData() {
      try {
        const connRes = await sendMessagePromise({ type: "FETCH_CONNECTED_CHANNEL" });
        if (connRes?.success && connRes?.data?.channel?.title) {
          connectedWorkspace = connRes.data.channel;
          renderAll();
        }
      } catch {
      }
    }
    async function syncActiveChannelAudit() {
      try {
        const detected = detectCurrentChannelInfo();
        if (!detected.isChannelPage) return;
        const queryKey = detected.handle || detected.title;
        if (queryKey && queryKey !== lastAuditedKey) {
          lastAuditedKey = queryKey;
          currentAuditedData = null;
          renderedCardKey = "";
          renderAll();
          const res = await sendMessagePromise({ type: "FETCH_AUDIT", query: queryKey });
          if (res?.success && res?.data?.data) {
            const freshDetected = detectCurrentChannelInfo();
            const freshKey = freshDetected.handle || freshDetected.title;
            if (freshKey === queryKey) {
              currentAuditedData = res.data.data;
              renderedCardKey = "";
              renderAll();
            }
          }
        }
      } catch {
      }
    }
    function observe() {
      renderAll();
      syncWorkspaceData();
      syncActiveChannelAudit();
      let renderTimer = null;
      const debouncedRender = () => {
        if (renderTimer) return;
        renderTimer = setTimeout(() => {
          renderTimer = null;
          renderAll();
        }, 400);
      };
      const observer = new MutationObserver(() => {
        debouncedRender();
      });
      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
      });
      window.addEventListener("yt-navigate-finish", () => {
        currentAuditedData = null;
        lastAuditedKey = "";
        renderedCardKey = "";
        setTimeout(() => {
          renderAll();
          syncActiveChannelAudit();
        }, 300);
      });
      window.addEventListener("popstate", () => {
        currentAuditedData = null;
        lastAuditedKey = "";
        renderedCardKey = "";
        setTimeout(() => {
          renderAll();
          syncActiveChannelAudit();
        }, 300);
      });
    }
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", observe);
    } else {
      observe();
    }
  })();
})();
//# sourceMappingURL=content.js.map
