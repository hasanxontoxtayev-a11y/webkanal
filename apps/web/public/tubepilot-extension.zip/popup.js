(() => {
  // src/popup.ts
  document.addEventListener("DOMContentLoaded", () => {
    const auditBtn = document.getElementById("btn-audit");
    const inputEl = document.getElementById("channel-input");
    if (auditBtn && inputEl) {
      auditBtn.addEventListener("click", () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const activeTab = tabs[0];
          if (activeTab?.id && activeTab?.url?.includes("youtube.com")) {
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              files: ["content.js"]
            }, () => {
              chrome.scripting.insertCSS({
                target: { tabId: activeTab.id },
                files: ["styles.css"]
              });
            });
          } else {
            const handle = inputEl.value.trim();
            const targetUrl = handle ? `https://www.tubepilotpro.com/uz/dashboard?audit_handle=${encodeURIComponent(handle)}` : `https://www.tubepilotpro.com/uz/dashboard`;
            chrome.tabs.create({ url: targetUrl });
          }
        });
      });
      inputEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          auditBtn.click();
        }
      });
    }
  });
})();
//# sourceMappingURL=popup.js.map
